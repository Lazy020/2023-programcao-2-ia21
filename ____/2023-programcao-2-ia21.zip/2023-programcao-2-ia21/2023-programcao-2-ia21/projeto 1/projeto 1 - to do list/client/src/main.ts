// const addButton = <HTMLButtonElement> document.querySelector("header button") or //as HTMLButtonElement;

// addButton.addEventListener("click", ev => {
//     alert("oi")
// })
void function main() {
    const btadd = document.querySelector("header .bt-add")
    const inpadd = document.querySelector("header .inp-add")
    const main = <HTMLElement> document.querySelector("main")
    const template = <HTMLTemplateElement> document.querySelector("main .savior")
    const check = <HTMLInputElement> document.querySelector("main div div .check")
    if (!btadd || !inpadd || !template) {
        return console.error("NO FREAKING BUTTON/INPUT/TEMPLATE")
    }

    if(!(inpadd instanceof HTMLInputElement)) {
        return console.error("THIS AIN'T A INPUT")
    }
    if(!(btadd instanceof HTMLButtonElement)) {
        return console.error("THIS AIN'T A BUTTON")
    }
    // if(!(template instanceof HTMLTemplateElement)) {
    //     return console.error("THIS AIN'T A TEMPLATE")
    // }

    btadd.addEventListener("click", () => {
        if(inpadd.value.trim() == "") return
        const line = template.content.cloneNode(true) as DocumentFragment
        const title = line.querySelector(".title") as HTMLElement
        const rem = line.querySelector(".rem") as HTMLButtonElement
        const check = line.querySelector(".check") as HTMLInputElement
        const hold = rem.closest(".holder") as HTMLElement

        rem.addEventListener("click", () => {
            hold.remove()
        })
        
        //rem.addEventlistener("click", () => rem.closest(".holder").remove())

        check.addEventListener("click", () => {
            const text = title.innerHTML
            const styled = "<s>"+title.innerHTML+"<s>"

            // if(check.checked == true) {
            //     hold.remove()
            //     title.innerHTML = styled
            //     main.append(line)
            // }
            // else {
            //     hold.remove()
            //     title.innerHTML = text
            //     main.prepend(line)
            // }
            
            if(check.checked == true) {
            title.innerHTML = styled
            }
            else {
                console.log("Unchecked")
                title.innerHTML = text
            }
        })

        title.innerHTML = inpadd.value
        inpadd.value = ""

        main.append(line)
    })
}();
